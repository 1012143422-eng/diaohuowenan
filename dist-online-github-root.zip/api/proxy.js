function setCors(res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST,OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
}

function sendJson(res, status, payload) {
  setCors(res);
  res.status(status).json(payload);
}

function normalizeBody(raw) {
  if (!raw) return {};
  if (typeof raw === 'string') {
    try {
      return JSON.parse(raw);
    } catch (error) {
      throw new Error('请求体不是合法 JSON');
    }
  }
  if (typeof raw === 'object') return raw;
  throw new Error('请求体格式不支持');
}

async function handler(req, res) {
  if (req.method === 'OPTIONS') {
    setCors(res);
    res.status(204).end();
    return;
  }

  if (req.method !== 'POST') {
    sendJson(res, 405, { error: { message: 'method not allowed' } });
    return;
  }

  let payload = {};
  try {
    payload = normalizeBody(req.body);
  } catch (error) {
    sendJson(res, 400, { error: { message: error.message } });
    return;
  }

  const endpointUrl = String(payload.endpointUrl || '').trim();
  if (!endpointUrl) {
    sendJson(res, 400, { error: { message: '缺少 endpointUrl' } });
    return;
  }

  let target;
  try {
    target = new URL(endpointUrl);
  } catch (error) {
    sendJson(res, 400, { error: { message: `端点 URL 不合法：${error.message}` } });
    return;
  }

  if (!/^https?:$/.test(target.protocol)) {
    sendJson(res, 400, { error: { message: '仅支持 http / https 端点' } });
    return;
  }

  const method = String(payload.method || 'POST').toUpperCase();
  const headers = { ...(payload.headers || {}) };
  const body = payload.body == null ? undefined : JSON.stringify(payload.body);

  try {
    const upstream = await fetch(target, { method, headers, body });
    const text = await upstream.text();
    const contentType = upstream.headers.get('content-type') || 'application/json; charset=utf-8';
    setCors(res);
    res.status(upstream.status);
    res.setHeader('Content-Type', contentType);
    res.send(text);
  } catch (error) {
    sendJson(res, 502, { error: { message: `代理请求失败：${error.message}` } });
  }
}

module.exports = handler;
module.exports.config = {
  api: {
    bodyParser: {
      sizeLimit: '2mb'
    }
  }
};

async function handler(req, res) {
  res.status(200).json({
    ok: true,
    mode: 'online',
    proxyPath: '/api/proxy'
  });
}

module.exports = handler;

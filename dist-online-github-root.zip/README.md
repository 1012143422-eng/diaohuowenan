# 老产品 AI 脚本工作台｜在线部署版

这是在线版。

目标只有一个：
把它部署成一个网址，别人打开网址后，在页面里填自己的 `API URL / Model / API Key` 就能用。

## 最短步骤

1. 新建一个 GitHub 仓库
2. 把当前 `dist-online` 目录里的内容传上去
3. 登录 Vercel
4. 点 `Add New...` → `Project`
5. 选刚才那个 GitHub 仓库，点 `Import`
6. 其他基本都不用改，直接 `Deploy`
7. 部署完成后，Vercel 会给你一个网址
8. 你把这个网址发给别人就行

## 仓库里应该是什么

仓库根目录直接放这几个东西，不要再多包一层 `dist-online` 文件夹：

- `public/index.html`
- `api/proxy.js`
- `api/health.js`
- `vercel.json`

## Vercel 导入时怎么填

- Framework Preset：不用特意选，保持自动识别即可
- Root Directory：仓库根目录
- Build Command：留空
- Output Directory：留空
- Environment Variables：留空

这套是纯静态页面 + Vercel Serverless API，不需要额外构建命令。

## 部署成功后怎么用

打开网址后，在页面右上角 `API 设置` 里填：

- 完整端点 URL
- 模型
- API Key

然后点 `测试连接`。

## 这版为什么能让别人电脑也用

- 页面本身在线访问
- 请求不再直接从浏览器打第三方接口
- 页面会优先走同源 `/api/proxy`
- 所以大部分浏览器跨域问题都被代理层兜住了

## 费用说明

- 页面本身不收费
- 真正费用来自用户自己填入的 API Key 调用

## 重要边界

- 这版解决的是浏览器跨域，不是 API 平台本身的计费、限流、封号
- 如果第三方接口本身不可用、Key 无效、模型名错误，页面还是会报错

## 你后面如果又改了主工作台 HTML

直接重新运行这个脚本：

`/Users/jay/.openclaw/workspace-xiaosou/scripts/rebuild_online_bundle.sh`

它会自动：

1. 重建 `dist-online`
2. 重打 `dist-online.zip`
